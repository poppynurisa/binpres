
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Unsri Lapor</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->
  <body style="background-color: ">
<nav class="navbar navbar-fixed-top">
         <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/unsri.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Layanan<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li class="active"><a href="kritik.php">kritik dan saran</a></li>
                    <li><a href="lapor.php">Lapor Fasilitas</a></li>
                  </ul>
                 <li><a href="beasiswa.php">Beasiswa</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.youtube.com/channel/UCkLQJRQX9g7fT_E3zD6eCdw">Youtube</a></li>
              </ul>
            </div>
        </div>
      </div>

</nav> 
<div class="jumbotron">
          <div class="container">
            <h1>Kritik dan Saran</h1>
            </div>
        </div>

        <div class="container">
<div class="row">
        <div class="col-md-8">

        <h4>
          Bantu USRI menjadi lebih baik dengan mengirimkan kritik dan saran. <br>
Kami tidak merekam identitas anda dalam penggunaan layanan ini.
        </h4><br>
            
  <form method="POST" action="actionkritik.php">
    <h5>Kepada  : Unsri</h5>        
    isi Pesan :
    <input type="text" name="pesan"> 
    <input type="hidden" name="waktu">
    <input type="submit" name="submit">
  </form>
        </div>
</div>
</div>
<br>
      <!-- FOOTER -->
    </div><!-- /.container -->
     <div class="panel-footer">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>
      


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
  </body>
</html>
