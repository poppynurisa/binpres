<?php 
    require 'koneksi.php';

    $tampil = query ("SELECT * FROM pelatih");

    if (isset($_POST["cari"])) {
      $tampil = cari($_POST["keywords"]);
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>DATA PELATIH</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->
  <body>
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/logokoni.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">DATA<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="atlet.php">atlet</a></li>
                    <li  class="active"><a href="pelatih.php">pelatih</a></li>
                  </ul>
                 <li><a href="admin.php">Admin</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php">Logout</a></li>
              </ul>
            </div>
        </div>
</div>


<section>
	 <div class="col-md-12" style="overflow: scroll;">
            <div class="table-responsive">
                 <h2>Data Pelatih</h2>
                 <form action="" method="post">
                  <div class="form-group col-md-6">
                   <input type="text" name="keywords" class="" placeholder="masukkan kata kunci">
                   <button type="submit" name="cari">Cari</button>
                  </div>
                  <a href="cetakpelatih.php" target="_blank">cetak</a>
                 </form>
  <br><br>
    <table id="tabel-data" class="table table-striped table-bordered" cellspacing="0" width="150%">
  <tr>
    <th>no</th>
    <th>Foto</th>
    <th>Nama pelatih</th>
    <th>Cabang Olahraga</th>
    <th>NIK</th>
    <th>Jenis Kelamin</th>
    <th>Tempat, Tanggal ahir</th>
    <th>alamat</th>
    <th>tinggi</th>
    <th>berat</th>
    <th>goldar</th>
    <th>pakaian</th>
    <th>sepatu</th>
    <th>topi</th>
  </tr> 

<?php $i=1; ?>
<?php foreach ($tampil as $x ) : //foreach itu pengulangan pada array  ?> 
  <tr>
    <td><?= $i; ?></td>
    <td><img src="img/<?= $x["gambar"];?>" width="70"></td>
    <td><?= $x["nama_pelatih"] ?></td>
    <td><?= $x["cabor_pelatih"] ?></td>
    <td><?= $x["nik_pelatih"] ?></td>
    <td><?= $x["jk_pelatih"] ?></td>
    <td><?= $x["ttl_pelatih"] ?></td>
    <td><?= $x["alamat_pelatih"] ?></td>
    <td><?= $x["tb_pelatih"] ?></td>
    <td><?= $x["bb_pelatih"] ?></td>
    <td><?= $x["goldar_pelatih"] ?></td>
    <td><?= $x["pakaian_pelatih"] ?></td>
    <td><?= $x["sepatu_pelatih"] ?></td>
    <td><?= $x["topi_pelatih"] ?></td>

    
  </tr>
<?php $i++; ?>
<?php endforeach; ?>
</table>
              </div>
           
</section>

   <!-- FOOTER -->
    </div><!-- /.container -->
     <div class="panel-footer">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
  </body>
</html>
