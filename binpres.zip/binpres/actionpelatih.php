<?php 
	require 'koneksi.php';

	$nama_pelatih = $_POST['nama_pelatih'];
	$cabor_pelatih = $_POST['cabor_pelatih'];
	$nik_pelatih = $_POST['nik_pelatih'];
	$ttl_pelatih = $_POST['ttl_pelatih'];
	$jk_pelatih = $_POST['jk_pelatih'];
	$alamat_pelatih = $_POST['alamat_pelatih'];
	$gambar = upload();
	$pakaian_pelatih = $_POST['pakaian_pelatih'];
	$sepatu_pelatih = $_POST['sepatu_pelatih'];
	$topi_pelatih = $_POST['topi_pelatih'];
	$tb_pelatih = $_POST['tb_pelatih'];
	$bb_pelatih = $_POST['bb_pelatih'];
	$goldar_pelatih = $_POST['goldar_pelatih'];
	


	$tambah = mysqli_query($conn,"INSERT INTO pelatih VALUES(null,'$nama_pelatih','$cabor_pelatih','$nik_pelatih','$ttl_pelatih','$jk_pelatih','$alamat_pelatih','$gambar','$pakaian_pelatih','$sepatu_pelatih','$topi_pelatih','$tb_pelatih','$bb_pelatih','$goldar_pelatih')");

	if ($tambah>0) {
		echo "<script>alert('Selamat! Data berhasil ditambahkan');window.location='inputpelatih.php'</script>";
	}
	else {
		echo "gagal ditambahkan";
	}


 ?>