
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Binpres Sumsel</title>
    <style type="text/css">
   .left    { text-align: left;}
   .right   { text-align: right;}
   .center  { text-align: center;}
   .justify { text-align: justify;}
    </style>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->
  <body>
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/logokoni.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li class="active"><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="inputatlet.php">Data Atlet</a></li>
                    <li><a href="inputpelatih.php">Data Pelatih</a></li>
                  </ul>
                 <li><a href="#">Contact</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.youtube.com/channel/UCGXGIoLgsrOaf0_YpDhIEdA">Youtube</a></li>
              </ul>
            </div>
        </div>

      </div>






      <section>
         <div class="container">
            <div class="row">
              <div class="col-lg-6">
                <font face="arial"><h2 >VISI KONI SUMSEL</h2> </font>
                <p class="justify">"KONI mempunyai tujuan mewujudkan prestasi olahraga yang membanggakan ditingkat dunia, membangun watak, mengangkat harkat dan martabat dan karakter kehormatan bangsa dalam rangka ikut serta mempererat, membina persatuan dan kesatuan bangsa, serta memperkokoh ketahanan nasional"</p>
              </div>
              <div class="col-lg-5">
                <ul class="justify">
                <font face="arial"><h2 >MISI KONI SUMSEL</h2> </font>
                <li>KONI menjadi induk organisasi yang profesional, modern dan mandiri</li>
                <li>Pembinaan usia dini dan peningkatan prestasi  atlet yang terencana dan berkesinambungan</li>
                <li>Turut serta mengembangkan Sport Science, Sport Industry dan Sport Tourism</li>
                </ul>
              </div>
            </div>
         </div>       
      </section>

      <section style="">
        <div class="container">
          <div class="row">
            <div class="col-md-6 offset-md-3">
              <font face="arial"><h2 >TUGAS POKOK</h2> </font>
              <p class="justify"><em>Komite Olahraga Nasional Sumsel (KONI) memiliki kewenangan dan tanggung jawab untuk mengelola, membina, mengembangkan & melakukan koordinasi pada seluruh pelaksanaan kegiatan olahraga prestasi di Sumatera Selatan.</em></p>
              <h5>Tugas mengacu Undang-Undang No. 3/2005 Sistem Keolahragaan Nasional</h5>
              <ul class="justify">
                <li>Membantu Pemerintah dalam membuat kebijakan Nasional bidang pengelolaan, pembinaan, dan pengembangan olahraga prestasi pada tingkat SUMSEL</li>
                <li>Mengoordinasikan induk organisasi cabang olahraga, organisasi olahraga fungsional, serta komite olahraga provinsi dan komite olahraga kabupaten/kota</li>
                <li>Melaksanakan pengelolaan, pembinaan dan pengembangan olahraga prestasi berdasarkan kewenangannya</li>
              </ul>
            </div>
            <div class="col-md-6 offset-md-3">
              <ul class="justify">
                <font face="arial"><h2 >STRATEGI DAN SASARAN</h2> </font>
                <li>Mendukung persiapan cabor Olimpiade dan mengupayakan kompetisi sistematis (Liga Siswa Indonesia, Indonesia Marathon dan sebagainya)</li>
                <li>Pengembangan produk olahraga domestik (Patriot)</li>
                <li>Menerapkan serta mendorong pengembangan Sport Science dengan minimal kelas Asia dan melakukan sosialisasi berbagai keilmuan Sport Science</li>
                <li>mengembangkan media dan konten publikasi guna menyampaikan kegiatan olahraga serta memasyarakatkan olahraga prestasi (KONI TV, Gerakita.com, Sportlink). Dalam bidang kehumasan melakukan komunikasi dengan berbagai pihak terkait olahraga prestasi</li>
                <li>Melakukan optimalisasi berbagai bidang di KONI Pusat seperti Binpres, Diktar, Sport Science, Litbang, Organisasi, Media dan Humas, Mobilisasi Sumber Daya, Pengumpulan dan Pengolahan Data, Kerja sama Dalam dan Luar Negeri</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    <!-- Marketing messaging and featurettes
    ================================================== -->
    <!-- Wrap the rest of the page in another container to center all the content. -->

    

      <!-- FOOTER -->
 <div><!-- /.container -->
     <div class="panel-footer" style="background-color: black">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>
    </div>
  </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
  </body>
</html>
