<?php 
	require 'koneksi.php';
	session_start();
	
	$nama = $_POST['nama'];
	$nim = $_POST['nim'];
	$password = $_POST['password'];
	$status = $_POST['status'];

	$result = mysqli_query($conn,"INSERT INTO user VALUES(null,'$nama','$nim','$password','$status')");

	//copy sampe sini btw ini dicopy dari action login




	if ($result) {
		echo "masuk bray!!!";
		echo("<br>");
		echo "login ";
		echo "<a href='login.php'>disini</a>";
		echo " bray";
	}
	else {
		echo "lu jelek belum mandi makanya gagal regis";
		echo "<a href='formregister.php'>try egen bray</a>";
	}


?>