<?php 
	include 'koneksi.php';
	$tampil = query ("SELECT * FROM pelatih");
	if (isset($_POST["cari"])) {
      $tampil = cari($_POST["keywords"]);
    }
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<table border="1" cellpadding="3" cellspacing="0"  width="100%">
  <tr>
    <th>no</th>
    <th>Foto</th>
    <th>Nama pelatih</th>
    <th>Cabang Olahraga</th>
    <th>NIK</th>
    <th>Jenis Kelamin</th>
    <th>Tempat, Tanggal ahir</th>
    <th>alamat</th>
    <th>tinggi</th>
    <th>berat</th>
    <th>goldar</th>
    <th>pakaian</th>
    <th>sepatu</th>
    <th>topi</th>
  </tr> 

<?php $i=1; ?>
<?php foreach ($tampil as $x ) : //foreach itu pengulangan pada array  ?> 
  <tr>
    <td><?= $i; ?></td>
    <td><img src="img/<?= $x["gambar"];?>" width="70"></td>
    <td><?= $x["nama_pelatih"] ?></td>
    <td><?= $x["cabor_pelatih"] ?></td>
    <td><?= $x["nik_pelatih"] ?></td>
    <td><?= $x["jk_pelatih"] ?></td>
    <td><?= $x["ttl_pelatih"] ?></td>
    <td><?= $x["alamat_pelatih"] ?></td>
    <td><?= $x["tb_pelatih"] ?></td>
    <td><?= $x["bb_pelatih"] ?></td>
    <td><?= $x["goldar_pelatih"] ?></td>
    <td><?= $x["pakaian_pelatih"] ?></td>
    <td><?= $x["sepatu_pelatih"] ?></td>
    <td><?= $x["topi_pelatih"] ?></td>

    
  </tr>
<?php $i++; ?>
<?php endforeach; ?>
</table>

	<script>
		window.print();
	</script>
 
</body>
</html>