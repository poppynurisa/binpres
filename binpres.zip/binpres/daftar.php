<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>REGISTRASI</title>
	<link rel="stylesheet" href="style.css">
	<form method="POST" action="actiondaftar.php">
 	
</head>
<body>
	<div class="box">
		<h2>Daftar dulu bray!!!</h2>
	<form>
		<div class="inputBox">
			<input type="text" name="nama" required="">
 			<label>nama</label>
		</div>
 		<br>
		<div class="inputBox">
			<input type="number" name="nim" required="">
			<label>nim</label>
		</div>	 
		<br>
		<div class="inputBox">
			<input type="password" name="password" required="">
			<label>password</label>
		</div>
		<br>
			<select name="status" >
     	 		<option value="mahasiswa">Mahasiswa</option>
 		 	</select>

 		 <br><br>

		<input type="submit" name="signup">

 
 	</form>

 </div>
</body>
</html>