<?php 
    require '../koneksi.php';

    $tampil = query ("SELECT * FROM atlet WHERE cbr_atlet='atletik'");
    $metu = query ("SELECT * FROM pelatih WHERE cabor_pelatih = 'atletik'")

   
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
 <h2 align="center" >ATLET ATLETIK</h2>
  <table border="1" cellpadding="3" cellspacing="0"  width="100%">
  <tr>
    <th>no</th>
    <th>Foto</th>
    <th>Nama Atlet</th>
    <th>Cabang Olahraga</th>
    <th>NIK</th>
    <th>Jenis Kelamin</th>
    <th>Tempat, Tanggal ahir</th>
    <th>alamat</th>
    <th>tinggi</th>
    <th>berat</th>
    <th>goldar</th>
    <th>pakaian</th>
    <th>sepatu</th>
    <th>topi</th>
  </tr> 

<?php $i=1; ?>
<?php foreach ($tampil as $x ) : //foreach itu pengulangan pada array  ?> 
  <tr>
    <td><?= $i; ?></td>
    <td><img src="img/<?= $x["gambar"];?>" width="70"></td>
    <td><?= $x["nama_atlet"] ?></td>
    <td><?= $x["cbr_atlet"] ?></td>
    <td><?= $x["nik_atlet"] ?></td>
    <td><?= $x["jk_atlet"] ?></td>
    <td><?= $x["ttl_atlet"] ?></td>
    <td><?= $x["alamat_atlet"] ?></td>
    <td><?= $x["tb_atlet"] ?></td>
    <td><?= $x["bb_atlet"] ?></td>
    <td><?= $x["goldar_atlet"] ?></td>
    <td><?= $x["pk_atlet"] ?></td>
    <td><?= $x["sepatu_atlet"] ?></td>
    <td><?= $x["topi_atlet"] ?></td>

    
  </tr>
<?php $i++; ?>
<?php endforeach; ?>
</table>


  <h2 align="center" >PELATIH ATLETIK</h2>
  <table border="1" cellpadding="3" cellspacing="0"  width="100%">
  <tr>
    <th>no</th>
    <th>Foto</th>
    <th>Nama Atlet</th>
    <th>Cabang Olahraga</th>
    <th>NIK</th>
    <th>Jenis Kelamin</th>
    <th>Tempat, Tanggal ahir</th>
    <th>alamat</th>
    <th>tinggi</th>
    <th>berat</th>
    <th>goldar</th>
    <th>pakaian</th>
    <th>sepatu</th>
    <th>topi</th>
  </tr> 

<?php $i=1; ?>
<?php foreach ($metu as $x ) : //foreach itu pengulangan pada array  ?> 
  <tr>
    <td><?= $i; ?></td>
    <td><img src="img/<?= $x["gambar"];?>" width="70"></td>
    <td><?= $x["nama_atlet"] ?></td>
    <td><?= $x["cbr_atlet"] ?></td>
    <td><?= $x["nik_atlet"] ?></td>
    <td><?= $x["jk_atlet"] ?></td>
    <td><?= $x["ttl_atlet"] ?></td>
    <td><?= $x["alamat_atlet"] ?></td>
    <td><?= $x["tb_atlet"] ?></td>
    <td><?= $x["bb_atlet"] ?></td>
    <td><?= $x["goldar_atlet"] ?></td>
    <td><?= $x["pk_atlet"] ?></td>
    <td><?= $x["sepatu_atlet"] ?></td>
    <td><?= $x["topi_atlet"] ?></td>

    
  </tr>
<?php $i++; ?>
<?php endforeach; ?>
</table>



  <script>
    window.print();
  </script>
 
</body>
</html>