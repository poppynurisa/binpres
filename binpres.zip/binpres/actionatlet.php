<?php 
	require 'koneksi.php';

	
	session_start();
    if (!isset($_SESSION['login'])) {
    echo "<script>alert('anda belum login, tolong login terlebih dahulu');window.location='login.php'</script>";
    exit;  
  }
 

	$nama_atlet = $_POST['nama_atlet'];
	$cbr_atlet = $_POST['cbr_atlet'];
	$nik_atlet = $_POST['nik_atlet'];
	$ttl_atlet = $_POST['ttl_atlet'];
	$jk_atlet = $_POST['jk_atlet'];
	$alamat_atlet = $_POST['alamat_atlet'];
	$gambar = upload();
	$pk_atlet = $_POST['pk_atlet'];
	$sepatu_atlet = $_POST['sepatu_atlet'];
	$topi_atlet = $_POST['topi_atlet'];
	$tb_atlet = $_POST['tb_atlet'];
	$bb_atlet = $_POST['bb_atlet'];
	$goldar_atlet = $_POST['goldar_atlet'];
	


	$tambah = mysqli_query($conn,"INSERT INTO atlet VALUES(null,'$nama_atlet','$cbr_atlet','$nik_atlet','$ttl_atlet','$jk_atlet','$alamat_atlet','$gambar','$pk_atlet','$sepatu_atlet','$topi_atlet','$tb_atlet','$bb_atlet','$goldar_atlet')");

	if ($tambah>0) {
		echo "<script>alert('Selamat! Data berhasil ditambahkan');window.location='inputatlet.php'</script>";
	}
	else {
		echo "gagal ditambahkan";
	}


 ?>