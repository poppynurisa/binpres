<?php 
	include 'koneksi.php';
 ?>

 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Binpres Sumsel</title>

    <!-- Bootstrap core CSS -->

<link href="bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this Form -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="form.css">





  </head>
<!-- NAVBAR
================================================== -->
  <body>
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/logokoni.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li class="active"><a href="atlet.php">Data Atlet</a></li>
                    <li><a href="pelatih.php">Data Pelatih</a></li>
                  </ul>
                 <li><a href="#">Contact</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.youtube.com/channel/UCGXGIoLgsrOaf0_YpDhIEdA">Youtube</a></li>
              </ul>
            </div>
        </div>

      </div>
<!-- END NAVBAR ================================================== -->
     
    <section>
      <form id="msform" action="actionatlet.php" method="post" role="form" enctype="multipart/form-data">
  <!-- progressbar -->
  <ul id="progressbar">
    <li class="active">biodata</li>
    <li>detail data</li>
    <li>detail pakaian</li>
  </ul>
  <!-- fieldsets -->
  <fieldset>
    <h2 class="fs-title">Masukkan data atlet</h2>
    <h3 class="fs-subtitle">This is step 1</h3>
    <select name="cbr_atlet" class="form-control">
                   <option>- cabor -</option>
                   <option value="Silat">Pencak Silat</option>
                   <option value="Karate">Karate</option> 
                   <option value="Muaythai">Muaythai</option> 
                   <option value="Gulat">Gukat</option> 
                   <option value="Taekwondo">Taekwondo</option> 
                   <option value="Menembak">Menembak</option> 
                   <option value="Loncat Indah">Loncat Indah</option> 
                   <option value="Biliar">Biliar</option> 
                   <option value="Senam">Senam</option> 
                   <option value="Anggar">Anggar</option> 
                   <option value="Panahan">Panahan</option> 
                   <option value="Catur">Catur</option> 
                   <option value="Voli Pasir">Voli Pasir</option> 
                   <option value="Bulu Tangkis">Bulu Tangkis</option> 
                   <option value="Tenis">Tenis</option> 
                   <option value="Takraw">Takraw</option> 
                   <option value="Tanis Meja">Tenis Meja</option> 
                   <option value="Wood Ball">Wood Ball</option> 
                   <option value="Atletik">Atletik</option> 
                   <option value="Dayung">Dayung</option>
                   <option value="Selam">Selam</option> 
                   <option value="Panjat Tebing">Panjat Tebing</option> 
                   <option value="Renang">Renang</option> 
                   <option value="Ski Air">Ski Air</option> 
                   <option value="Sepeda">Sepeda</option> 
                   <option value="Sepatu Roda">Sepatu Roda</option>
    </select><br>
    <input type="text" name="nama_atlet" placeholder="nama" required />
    <input type="number" name="nik_atlet" placeholder="nik" required>
    <input type="text" name="ttl_atlet" placeholder="Tempat, tanggal lahir" required />
    <select name="jk_atlet" class="form-control" required>
                   <option>- gender -</option>
                   <option value="Laki-Laki">Laki-Laki</option>
                   <option value="Perempuan">Perempuan</option> 
    </select>
    <input type="button" name="next" class="next action-button" value="Next" />
  </fieldset>


  <fieldset>
    <h2 class="fs-title">Data Profiles</h2>
    <h3 class="fs-subtitle">athlete's personal details</h3>
    <textarea name="alamat_atlet" placeholder="alamat"></textarea>
    <input type="text" name="goldar_atlet" placeholder="goldar" />
    <input type="text" name="tb_atlet" placeholder="tinggi" />
    <input type="text" name="bb_atlet" placeholder="berat" />
        <input type="file" name="gambar" required id="gambar" required />
    <input type="button" name="previous" class="previous action-button" value="Previous" />
    <input type="button" name="next" class="next action-button" value="Next" />
  </fieldset>


  <fieldset>
    <h2 class="fs-title">Detail Pakaian</h2>
    <h3 class="fs-subtitle">the last step</h3>
    <input type="text" name="pk_atlet" placeholder="size baju" />
    <input type="text" name="sepatu_atlet" placeholder="size sepatu" />
    <input type="text" name="topi_atlet" placeholder="size topi" />
    <input type="button" name="previous" class="previous action-button" value="Previous" /><br>
    <button type="submit">submit</button>
  </fieldset>
</form>
    </section>

  





    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>
  <script  src="script.js"></script>


  </body>
</html>

