
<?php 
    require 'koneksi.php';
    session_start();
  if (!isset($_SESSION['login'])) {
    header("location: login.php");
    exit;  
  } 
    $tampil = query ("SELECT * FROM atlet");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>ADMIN BINPRES</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->
  <body>
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/logokoni.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">DATA<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="atlet.php">atlet</a></li>
                    <li><a href="pelatih.php">pelatih</a></li>
                  </ul>
                 <li class="active"><a href="admin.php">Admin</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php">Logout</a></li>
              </ul>
            </div>
        </div>
</div>


    <!-- Marketing messaging and featurettes
    ================================================== -->
    
    <div class="container marketing">

  <div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
          Bidang Beladiri
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in">
      <div class="panel-body">
         <button onclick="window.location.href='cabor/karate.php'">Karate</button> 
         <button onclick="window.location.href='cabor/muaythai.php'">Muaythai</button>
         <button onclick="window.location.href='cabor/silat.php'">Pencak Silat</button>
         <button onclick="window.location.href='cabor/taekwondo.php'">Taekwondo</button>
         <button onclick="window.location.href='cabor/gulat.php'">Gulat</button>
         <button onclick="window.location.href='cabor/wushu.php'">Wushu</button>
      </div>
    </div>
  </div>

  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
          Bidang Permainan
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse">
      <div class="panel-body">
         <button onclick="window.location.href='cabor/bulutangkis.php'">Bulu Tangkis</button> 
         <button onclick="window.location.href='cabor/catur.php'">Catur</button>
         <button onclick="window.location.href='cabor/volipasir.php'">Voli Pasir</button>
         <button onclick="window.location.href='cabor/woodball.php'">WoodBall</button>
         <button onclick="window.location.href='cabor/tenislapangan.php'">Tenis Lapangan</button>
         <button onclick="window.location.href='cabor/tenismeja.php'">Tenis Meja</button>
         <button onclick="window.location.href='cabor/takraw.php'">Sepak Takraw</button>
      </div>
    </div>
  </div>

  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
          Bidang Terukur
        </a>
      </h4>
    </div>
    <div id="collapseFour" class="panel-collapse collapse">
      <div class="panel-body">
        <button onclick="window.location.href='cabor/atletik.php'">Atletik</button>
        <button onclick="window.location.href='cabor/dayung.php'">Dayung</button>
        <button onclick="window.location.href='cabor/selam.php'">Selam</button>
        <button onclick="window.location.href='cabor/panjattebing.php'">Panjat Tebing</button>
        <button onclick="window.location.href='cabor/renang.php'">Renang</button>
        <button onclick="window.location.href='cabor/bermotor.php'">Bermotor</button>
        <button onclick="window.location.href='cabor/skiair.php'">Ski Air</button>
        <button onclick="window.location.href='cabor/balapsepeda.php'">Balap Sepeda</button>
        <button onclick="window.location.href='cabor/sepaturoda.php'">Sepatu Roda</button>
      </div>
    </div>
  </div>

  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
          Bidang Akurasi
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse">
      <div class="panel-body">
         <button onclick="window.location.href='cabor/menembak.php'">Menembak</button>
         <button onclick="window.location.href='cabor/loncatindah.php'">Loncat Indah</button>
         <button onclick="window.location.href='cabor/biliar.php'">Biliar</button>
         <button onclick="window.location.href='cabor/senam.php'">Senam</button>
         <button onclick="window.location.href='cabor/anggar.php'">Anggar</button>
         <button onclick="window.location.href='cabor/panahan.php'">Panahan</button>
      </div>
    </div>
  </div>
      
      <!-- /END THE FEATURETTES -->
</div>
</div>

      <!-- FOOTER -->
    </div><!-- /.container -->
     <div class="panel-footer">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
  </body>
</html>
