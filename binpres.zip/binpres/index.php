<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Binpres KONI Sumsel</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->
  <body>
<nav class="navbar navbar-fixed-top">
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/logokoni.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="inputatlet.php">Data Atlet</a></li>
                    <li><a href="inputpelatih.php">Data Pelatih</a></li>
                  </ul>
                 <li><a href="#">Contact</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.youtube.com/channel/UCGXGIoLgsrOaf0_YpDhIEdA">Youtube</a></li>
              </ul>
            </div>
        </div>

</nav>
    <!-- Carousel
    ================================================== -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">

      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <div class="first-slide"   alt="First slide">
          <div class="container">
            <div class="carousel-caption">
              <img src="foto/logokoni.png"  height="300px" width="300px" >
              <h1>Selamat Datang di Website Binpres Koni Sumsel</h1>
            </div>
          </div>
          </div>
        </div>
        <div class="item">
          <img class="second-slide" src="foto/satu.jpg" alt="Second slide">
          <div class="container">
            <div class="carousel-caption">
              <h2 style="color: white">Komite Olahraga Nasional Indonesia (KONI) adalah satu-satunya organisasi yang berwenang dan bertanggung jawab mengelola, membina, mengembangkan & mengkoordinasikan seluruh pelaksanaan kegiatan olahraga prestasi setiap anggota di Indonesia</h2>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="third-slide" src="foto/koni2.jpg" alt="Third slide">
          <div class="container">
            <div class="carousel-caption">
              <h2 style="color: black">Pelantikan KONI SUMSEL</h2>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="fourth-slide" src="foto/swim.jpg" alt="fourth slide">
          <div class="container">
            <div class="carousel-caption">
              <h2 style="color: white">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
              quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.</h2>
            </div>
          </div>
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div><!-- /.carousel -->



    <!-- Marketing messaging and featurettes
    ================================================== -->
    <!-- Wrap the rest of the page in another container to center all the content. -->    
<section>
    <div class="container">

      <!-- Three columns of text below the carousel -->
      <div class="row">
        <div class="col-lg-4">
          <img class="img-circle" src="foto/1.jpg" width="250px" height="250px">
          <h3>Gelorakan Olahraga di Tengah Pandemi, Gubernur Sumsel Buka Kejuaraan Badminton Elang Nusantara</h3>
          <p>Sejak pandemi Covid-19 beberapa event olahraga turut menjadi imbas, tak pelak ajang olahragapun harus dibiarkan mati suri.Seperti halnya Liga Indonesia dan juga PON Papua yang mengalami penghentian serta mengalami kemunduran jadwal.Kendati begitu Pemprov Sumsel dalam halnya Gubernur Sumsel Herman Deru tengah melakukan upaya untuk tetap menggelelorakan olahraga</p>
          <p><a class="btn btn-default" href="https://fixpalembang.pikiran-rakyat.com/olahraga/pr-471322692/gelorakan-olahraga-di-tengah-pandemi-gubernur-sumsel-buka-kejuaraan-badminton-elang-nusantara" role="button">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="img-circle" src="foto/duaa.jpg" width="250px" height="250px">
          <h3>Bahas Tiga Agenda Besar, Raker KONI Sumsel Fokus Bina Atlet Lokal Haramkan Beli Atlet Luar</h3>
          <p>Rapat Kerja (Raker) KONI Sumatera Selatan membahas tiga agenda besar, salah satunya KONI bersama jajaran diminta untuk membina atlet.Sesuai dengan arahan dari Gubernur Sumsel H Herman Deru pada Rakor KONI Sumsel, Rabu 23 Desember 2020.Orang nomor satu di Pelambang ini meminta KONI Sumsel bersama jajaran untuk fokus kepada pembinaan atlet dan mengharamkan membeli atlet luar.</p>
          <p><a class="btn btn-default" href="https://fixpalembang.pikiran-rakyat.com/olahraga/pr-471153824/bahas-tiga-agenda-besar-raker-koni-sumsel-fokus-bina-atlet-lokal-haramkan-beli-atlet-luar" role="button">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->

        <div class="col-lg-4">
          <img class="img-circle" src="foto/tigaaa.jpg" width="250px" height="250px">
          <h3>Demi Perbaiki Peringkat, KONI Sumsel Bakal Launching Pelatda PON Papua Febuari Mendatang</h3>
          <p>Komite Olahraga Nasional (KONI) Sumsel dan Pemerintah Sumatera Selatan (Pemprov Sumsel). Saat ini tengah mempersiapkan Launcing Pelatda PON Papua, di Griya Agung pada, 15 Febuari 2021. PON Papua sendiri akan dilaksanakan pada Oktober 2021 mendatang di Papua.</p>
          <p><a class="btn btn-default" href="https://fixpalembang.pikiran-rakyat.com/olahraga/pr-471309662/demi-perbaiki-peringkat-koni-sumsel-bakal-launching-pelatda-pon-papua-febuari-mendatang" role="button">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->

</section>

<section class="social"  id="social" style="background-color: darkgrey">
  <div class="container">
    <div class="row">
      <div class="col text-center">
        <h2>Social Media</h2>
      </div>
    </div>
    <div class="row justify-content-center">

      <div class="col-md-5">
        <div class="row">
          <div class="col-md-4">
           
        </div><br>
        <div class="row mt-3 pb-3">
         
        </div>
      </div>
      <div class="col-md-5"></div>
    </div>
  </div>
</section>  
      <!-- /END THE FEATURETTES -->


      <!-- FOOTER -->
    <div><!-- /.container -->
     <div class="panel-footer" style="background-color: black">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>
    </div>
  </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
    <script src="https://apis.google.com/js/platform.js"></script>
  </body>
</html>
