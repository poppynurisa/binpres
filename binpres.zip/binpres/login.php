<?php 
	session_start();
	if (isset($_SESSION['login'])) {
		header("location : admin.php");
		exit;
	}

	include 'koneksi.php';
 ?>

 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Login</title>

    <!-- Bootstrap core CSS -->

<link href="bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this Form -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="form.css">





  </head>
<!-- NAVBAR
================================================== -->
  <body>
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/logokoni.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li class="active"><a href="atlet.php">Data Atlet</a></li>
                    <li><a href="pelatih.php">Data Pelatih</a></li>
                  </ul>
                 <li><a href="#">Contact</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.youtube.com/channel/UCkLQJRQX9g7fT_E3zD6eCdw">Youtube</a></li>
              </ul>
            </div>
        </div>

      </div>
<!-- END NAVBAR ================================================== -->
     
    <section>
      <form id="msform" action="actionlogin.php" method="post" role="form" enctype="multipart/form-data">
  
  <!-- fieldsets -->
  <fieldset>
    <h2 class="fs-title">Form Login</h2>
    <h3 class="fs-subtitle"></h3>
    <input type="text" name="username" placeholder="username" required />
    <input type="password" name="password" placeholder="password" required>
    <button type="submit" style="box-shadow: 0 0 0 2px black, 0 0 0 3px #131b22;">login</button>
  </fieldset>


    </section>

  





    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>
  <script  src="script.js"></script>


  </body>
</html>

