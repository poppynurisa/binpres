<?php 
	session_start();
	
	session_destroy();

	header("location: index.php");
	exit;
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 
 </body>
 </html>