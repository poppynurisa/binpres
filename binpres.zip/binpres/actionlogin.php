 <?php 
	require 'koneksi.php';
	session_start();
	//$nama = $_POST['nama'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$sts = $_POST['sts'];


	$result = mysqli_query($conn,"SELECT * FROM user where username='$username' and password ='$password'");

	$data	= mysqli_fetch_assoc($result);

 	if (mysqli_num_rows($result)>0){
 		//login
 		$_SESSION['login'] = true;
 		$_SESSION['username'] = $username;
 		$_SESSION['id'] = $data['id'];
 		$_SESSION['sts'] = $data['sts'];
 			
 			if ($data['sts']=="admin") {
 				header("location: admin.php");
 			}
 			else if ($data['sts']=="guest") {
 				header("location: index.php");
 			}
 	}
 	
 	
 	else {
 		echo "<script>alert('anda gagal login');window.location='login.php'</script>";
 	}

?>